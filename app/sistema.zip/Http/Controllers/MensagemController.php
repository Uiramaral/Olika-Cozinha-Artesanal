<?php

namespace App\Http\Controllers;

use App\Services\ChatService;
use App\Services\ClienteService;
use App\Services\HistoricoConversaService;
use App\Services\pedidoService;
use App\Models\HistoricoConversa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MensagemController extends Controller
{
    protected $chatService;
    protected $clienteService;
    protected $historicoConversaService;

    public function __construct(ChatService $chatService, ClienteService $clienteService, HistoricoConversaService $historicoConversaService)
    {
        $this->chatService = $chatService;
        $this->clienteService = $clienteService;
        $this->historicoConversaService = $historicoConversaService;
    }

    public function receberMensagem(Request $request)
    {
        \Log::info('Iniciando o processamento da mensagem recebida', [
            'request_data' => $request->all()
        ]);

        // 1. Validar os dados do request
        $validator = Validator::make($request->all(), [
            'message' => 'required|string',
            'from' => 'required|string',
        ]);

        if ($validator->fails()) {
            \Log::error('Validação de request falhou', ['errors' => $validator->errors()]);
            return response()->json(['error' => $validator->errors()], 400);
        }

        // Extrair a mensagem do corpo do request (após a validação)
        $mensagem = $request->input('message');
        $telefone = $request->input('from');

        \Log::info('Mensagem e telefone extraídos', ['mensagem' => $mensagem, 'telefone' => $telefone]);

        try {
            // 2. Verificar se o cliente já está cadastrado com base no número de telefone
            \Log::info('Verificando cliente pelo telefone', ['telefone' => $telefone]);
            $cliente = $this->clienteService->verificarCliente($telefone);

            // 3. Se o cliente não estiver cadastrado, criar um novo
            if (!$cliente) {
                \Log::info('Cliente não encontrado, cadastrando novo cliente', ['telefone' => $telefone]);
                $cliente = $this->clienteService->cadastrarCliente($telefone);
            } else {
                \Log::info('Cliente encontrado', ['cliente_id' => $cliente->id]);
            }

            // Definir o histórico e gerar a resposta com a IA (incluindo o histórico)
            $historico = $this->historicoConversaService->obterContexto($cliente->id);
            \Log::info('Contexto obtido para o cliente', ['historico' => $historico]);

            // Analisar a mensagem usando IA
            \Log::info('Analisando e respondendo a mensagem', ['mensagem' => $mensagem]);
            $resposta = $this->chatService->analisarEResponderMensagem($mensagem, $cliente);

            \Log::info('Resposta gerada com sucesso', ['resposta' => $resposta]);
            return response()->json(['response' => $resposta]);

        } catch (\Exception $e) {
            // Log do erro
            \Log::error('Erro ao processar mensagem: ' . $e->getMessage(), [
                'mensagem' => $mensagem,
                'telefone' => $telefone
            ]);
            return response()->json(['error' => 'Erro ao processar mensagem. Detalhes: ' . $e->getMessage()], 500);
        }
    }

}
