<?php

namespace App\Services;

use App\Models\Cliente;
use App\Services\OpenAiService;
use App\Services\HistoricoConversaService;
use App\Services\PedidoService;

class ChatService
{
    protected $openAiService;
    protected $historicoConversaService;
    protected $pedidoService;

    public function __construct(OpenAiService $openAiService, HistoricoConversaService $historicoConversaService, PedidoService $pedidoService)
    {
        $this->openAiService = $openAiService;
        $this->historicoConversaService = $historicoConversaService;
        $this->pedidoService = $pedidoService;
    }

    /**
     * Retorna os contextos possíveis como um array.
     *
     * @return array Contextos possíveis.
     */
    private function obterContextos(): array
    {
        return [
            'duvida' => 'Dúvida sobre produtos ou serviços',
            'compra' => 'Pedido de compra ou informação sobre produtos',
            'entrega' => 'Rastreamento de entrega ou problema com a entrega',
            'telemarketing' => 'Oferta de produtos ou serviços',
            'conversacao' => 'Conversa casual ou cumprimento',
            // ... outros contextos
        ];
    }

    /**
     * Gera um prompt para a IA classificar o contexto da mensagem.
     *
     * @param string $mensagem A mensagem do usuário.
     * @return string O prompt para a IA.
     */
    private function gerarPromptContexto(string $mensagem): string
    {
        $contextos = $this->obterContextos();

        $prompt = "Classifique o contexto da seguinte mensagem:\n\n";
        $prompt .= "$mensagem\n\n";
        $prompt .= "Contextos possíveis:\n";
        foreach ($contextos as $chave => $descricao) {
            $prompt .= "- $chave: $descricao\n";
        }
        $prompt .= "\nResponda apenas com a chave do contexto mais adequado.";

        return $prompt;
    }

    /**
     * Analisa a mensagem e retorna o contexto identificado pela IA.
     *
     * @param string $mensagem A mensagem do usuário.
     * @return string O contexto da mensagem.
     */
    public function analisarContexto(string $mensagem): string
    {
        $contextos = $this->obterContextos();
        $prompt = $this->gerarPromptContexto($mensagem);

        $respostaIA = $this->openAiService->gerarResposta($prompt); // Chama a API do OpenAI
        $contexto = strtolower(trim($respostaIA));

        // Verifica se o contexto está entre os contextos possíveis
        return array_key_exists($contexto, $contextos) ? $contexto : 'conversacao';
    }

    /**
     * Gera o prompt para a IA com base no contexto da mensagem.
     *
     * @param string $mensagem A mensagem do usuário.
     * @param string $contexto O contexto da mensagem.
     * @param array $contextoConversa O contexto da conversa.
     * @return string O prompt para a IA.
     */
    private function gerarPrompt(string $mensagem, string $contexto, array $contextoConversa): string
    {
        switch ($contexto) {
            case 'duvida':
                $prompt = "Responda à dúvida do usuário:\n\n$mensagem\n\n";
                $prompt .= "Contexto da conversa:\n";
                // ... (incluir informações relevantes do contexto da conversa) ...
                break;

            case 'compra':
                $prompt = "Ajude o usuário com o pedido de compra:\n\n$mensagem\n\n";
                $prompt .= "Produtos disponíveis:\n";
                // ... (incluir informações sobre produtos) ...
                break;

            // ... (outros casos para diferentes contextos) ...

            default:
                $prompt = "Responda à mensagem do usuário:\n\n$mensagem\n\n";
                // ... (incluir informações gerais) ...
                break;
        }

        return $prompt;
    }

    private function gerarPromptAtendimentoGeneralizado(): string
    {
        return "
        Você é Pedro, um assistente virtual. Sua missão é ajudar os clientes a resolverem suas dúvidas e processar seus pedidos de forma humanizada e fluida. Não se interrompa para cumprimentos ou despedidas e use uma linguagem amigável.

        Exemplo de interação:
        - Cliente: Eu gostaria de realizar um pedido.
        - Pedro: Claro! Posso ajudar com isso. Você já tem o que gostaria de pedir?
        - Cliente: Sim, quero 2 pães rústicos.
        - Pedro: Perfeito! O total será X. Como você gostaria de pagar?

        Sempre que uma mensagem for longa demais, utilize `#!` para quebrar em partes.
        ";
    }

    public function analisarEResponderMensagem($mensagem, Cliente $cliente)
    {
        \Log::info('Iniciando a análise da mensagem', ['mensagem' => $mensagem, 'cliente_id' => $cliente->id]);

        // 1. Analisar o contexto da mensagem
        $contexto = $this->analisarContexto($mensagem);
        \Log::info('Contexto analisado', ['contexto' => $contexto]);

        // 2. Obter o contexto da conversa
        $contextoConversa = $this->historicoConversaService->obterContexto($cliente->id);
        \Log::info('Contexto da conversa obtido', ['contextoConversa' => $contextoConversa]);

        // 3. Formatar o contexto para a API do OpenAI
        $messages = $this->formatarContextoParaOpenAI($contextoConversa);
        \Log::info('Contexto formatado para OpenAI', ['messages' => $messages]);

        // 4. Adicionar o contexto identificado ao prompt
        $messages[] = ['role' => 'user', 'content' => "Contexto da mensagem: $contexto"];

        // 5. Inicializa a variável resposta com um valor padrão
        $resposta = 'Desculpe, não consegui entender a mensagem.'; // Resposta padrão

        // 6. Verifica se a mensagem contém detalhes do pedido
        if (strpos($mensagem, '*NÚMERO DO PEDIDO*') !== false) {
            \Log::info('Mensagem contém detalhes do pedido, processando...', ['mensagem' => $mensagem]);

            try {
                $dadosPedido = $this->pedidoService->processarPedidoMensagem($mensagem);
                \Log::info('Pedido processado com sucesso', ['dadosPedido' => $dadosPedido]);

                // Aqui você pode gerar uma resposta baseada no pedido
                $resposta = $this->gerarRespostaConsumidor($dadosPedido);
            } catch (\Exception $e) {
                \Log::error('Erro ao processar o pedido: ' . $e->getMessage(), [
                    'mensagem' => $mensagem,
                    'cliente_id' => $cliente->id
                ]);
                $resposta = 'Houve um erro ao processar seu pedido. Tente novamente mais tarde.';
            }
        } else {
            try {
                // Tentar analisar a mensagem usando IA
                \Log::info('Chamando OpenAI para gerar resposta', ['mensagem' => $mensagem]);
                $resposta = $this->openAiService->gerarResposta($mensagem, $messages);
                \Log::info('Resposta gerada da IA', ['resposta' => $resposta]);

                if (empty($resposta)) {
                    \Log::warning('Resposta da IA vazia', ['mensagem' => $mensagem]);
                    $resposta = 'Desculpe, não consegui entender a mensagem.';
                }
            } catch (\Exception $e) {
                \Log::error('Erro ao gerar resposta da IA: ' . $e->getMessage(), [
                    'mensagem' => $mensagem,
                    'cliente_id' => $cliente->id
                ]);
            }
        }

        // 7. Salvar a mensagem e resposta no histórico
        $this->historicoConversaService->registrarMensagem($cliente->id, $mensagem, $resposta, 'enviada');

        // 8. Atualizar o contexto com a nova mensagem e resposta
        $novoContexto = $this->atualizarContexto($contextoConversa, $mensagem, $resposta);
        \Log::info('Novo contexto atualizado', ['novoContexto' => $novoContexto]);

        // 9. Salvar o contexto atualizado
        $this->historicoConversaService->salvarContexto($cliente->id, $novoContexto);

        // 10. Retornar a resposta da IA
        \Log::info('Retornando resposta', ['resposta' => $resposta]);
        return $resposta;
    }

    /**
     * Formata o contexto da conversa para o formato esperado pela API do OpenAI.
     *
     * @param array $contexto O contexto da conversa.
     * @return array O contexto formatado para a API do OpenAI.
     */
    private function formatarContextoParaOpenAI(array $contexto): array
    {
        $messages = [];
        foreach ($contexto as $mensagem) {
            $messages[] = [
                'role' => $mensagem['tipo'] == 'enviada' ? 'user' : 'assistant',
                'content' => $mensagem['mensagem'],
            ];
        }
        return $messages;
    }

    /**
     * Atualiza o contexto da conversa com a nova mensagem e resposta.
     *
     * @param array $contexto O contexto atual da conversa.
     * @param string $mensagem A nova mensagem do usuário.
     * @param string $resposta A resposta da IA.
     * @return array O contexto atualizado.
     */
    private function atualizarContexto(array $contexto, string $mensagem, string $resposta): array
    {
        $contexto[] = ['tipo' => 'enviada', 'mensagem' => $mensagem];
        $contexto[] = ['tipo' => 'recebida', 'mensagem' => $resposta];
        return $contexto;
    }
}
