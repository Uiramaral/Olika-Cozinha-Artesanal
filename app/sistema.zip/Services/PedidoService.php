<?php

namespace App\Services;

use App\Models\Pedido;
use Illuminate\Support\Collection;
use App\Models\Cliente;
use App\Services\ClienteService;

class PedidoService
{
    protected $clienteService;

    public function __construct(ClienteService $clienteService) // Injete o ClienteService no construtor
    {
        $this->clienteService = $clienteService; // Inicialize a propriedade aqui
    }

    public function criarPedido(array $dados): Pedido
    {
        return Pedido::create($dados);
    }

    public function atualizarStatusPedido(int $id, string $status): Pedido
    {
        $pedido = Pedido::findOrFail($id);
        $pedido->status = $status;
        $pedido->save();
        return $pedido;
    }

    public function calcularTotalPedido(Pedido $pedido): float
    {
        $total = $pedido->produtos->sum(fn($produto) => $produto->preco * $produto->quantidade);
        return $total;
    }

    public function buscarPedidoPorId(int $id): ?Pedido
    {
        return Pedido::find($id);
    }

    public function listarPedidos(array $filtros = []): Collection
    {
        return Pedido::query()->filter($filtros)->get();
    }

    public function sugerirAdicionais(Pedido $pedido): array
    {
        // Lógica para sugerir adicionais com base no pedido
        return [];
    }

    public function processarPedido(string $mensagem): array
    {
        // Parâmetros de entrada
        try {
            // 1. Analisar a mensagem para extrair dados do pedido
            $dados = $this->extrairDadosPedido($mensagem);

            // 2. Encontrar o cliente pelo ID extraído
            $cliente = Cliente::find($dados['clienteId']);
            if (!$cliente) {
                \Log::error('Cliente não encontrado ao processar pedido', ['mensagem' => $mensagem]);
                throw new \Exception('Cliente não encontrado.');
            }

            // 3. Calcular o desconto para o primeiro pedido
            $primeiroPedidoDesconto = $cliente->primeiroPedido ? 0.1 : 0;
            $cashbackDisponivel = $cliente->cashback;

            // 4. Calcular o subtotal dos itens do pedido
            $subtotal = collect($dados['itens'])->sum('preco');
            $desconto = $subtotal * $primeiroPedidoDesconto + $cashbackDisponivel;
            // 5. Calcular o total a pagar
            $total = max($subtotal - $desconto + $dados['taxaEntrega'], 0);

            // 6. Validar que o total não pode ser negativo
            if ($total < 0) {
                \Log::error('O valor total calculado é negativo.', [
                    'subtotal' => $subtotal,
                    'desconto' => $desconto,
                    'taxaEntrega' => $dados['taxaEntrega'],
                    'mensagem' => $mensagem
                ]);
                throw new \Exception('O valor total não pode ser negativo.');
            }

            // 7. Usando Eloquent para atualizar os dados do cliente
            $cliente->primeiroPedido = $primeiroPedidoDesconto > 0 ? 0 : $cliente->primeiroPedido;
            $cliente->cashback = max(0, $cashbackDisponivel - $total);
            $cliente->save();

            // 8. Retornar os dados do cliente e do pedido processado
            return [
                'cliente' => [
                    'nome' => $cliente->nome,
                ],
                'itens' => $dados['itens'],
                'subtotal' => $subtotal,
                'desconto' => $desconto,
                'taxaEntrega' => $dados['taxaEntrega'],
                'total' => $total,
            ];
        } catch (\Exception $e) {
            // 9. Logando o erro caso ocorra alguma falha no processamento
            \Log::error('Erro ao processar pedido: ' . $e->getMessage(), ['mensagem' => $mensagem]);
            throw $e; // Relançar o erro para ser tratado em outro lugar, se necessário
        }
    }

    private function extrairDadosPedido(string $mensagem): array
    {
        // Lógica ou IA para extrair dados do pedido
        return [
            'clienteId' => 1,
            'itens' => [
                ['nome' => 'Rústico com crosta de sementes', 'quantidade' => 1, 'preco' => 26.00],
                ['nome' => 'Pão rústico tradicional', 'quantidade' => 1, 'preco' => 21.00],
                ['nome' => 'Forma integral', 'quantidade' => 1, 'preco' => 20.00],
            ],
            'taxaEntrega' => 10.50,
        ];
    }

    public function processarPedidoMensagem(string $mensagem): array
    {
        \Log::info('Iniciando o processamento da mensagem do pedido', ['mensagem' => $mensagem]);

        try {
            // 1. Extrair dados do pedido
            $dados = $this->extrairDadosPedido($mensagem);
            \Log::info('Dados do pedido extraídos com sucesso', ['dados' => $dados]);

            // 2. Verificar se o cliente já está cadastrado com base no número de telefone
            $cliente = $this->clienteService->verificarCliente($dados['telefone']); // Usar a função verificarCliente
            if (!$cliente) {
                \Log::error('Cliente não encontrado ao processar pedido', ['telefone' => $dados['telefone']]);
                throw new \Exception('Cliente não encontrado.');
            }

            \Log::info('Cliente encontrado', ['cliente_id' => $cliente->id]);

            // 3. Calcular descontos
            $primeiroPedidoDesconto = $cliente->primeiroPedido ? 0.1 : 0; // 10% de desconto para o primeiro pedido
            $cashbackDisponivel = $cliente->cashback;

            // 4. Calcular o subtotal dos itens do pedido
            $subtotal = collect($dados['itens'])->sum(function ($item) {
                return $item['preco'] * $item['quantidade'];
            });

            \Log::info('Subtotal calculado', ['subtotal' => $subtotal]);

            // 5. Calcular total e desconto
            $desconto = $subtotal * $primeiroPedidoDesconto + $cashbackDisponivel;
            $total = max($subtotal - $desconto + $dados['taxaEntrega'], 0);

            // 6. Validar total não negativo
            if ($total < 0) {
                \Log::error('O valor total calculado é negativo.', [
                    'subtotal' => $subtotal,
                    'desconto' => $desconto,
                    'taxaEntrega' => $dados['taxaEntrega'],
                    'mensagem' => $mensagem
                ]);
                throw new \Exception('O valor total não pode ser negativo.');
            }

            // 7. Atualizar dados do cliente
            $cliente->primeiroPedido = $primeiroPedidoDesconto > 0 ? 0 : $cliente->primeiroPedido; // Atualiza o status do primeiro pedido
            $cliente->cashback = max(0, $cashbackDisponivel - $total); // Atualiza o cashback do cliente
            $cliente->save();

            // 8. Retornar os dados processados
            return [
                'cliente' => [
                    'nome' => $cliente->nome,
                ],
                'itens' => $dados['itens'],
                'subtotal' => $subtotal,
                'desconto' => $desconto,
                'taxaEntrega' => $dados['taxaEntrega'],
                'total' => $total,
            ];

        } catch (\Exception $e) {
            \Log::error('Erro ao processar a mensagem do pedido: ' . $e->getMessage(), [
                'mensagem' => $mensagem
            ]);
            throw $e; // Relançar o erro para que seja tratado em outro lugar
        }
    }

    public function processarPagamento(array $dadosPedido)
    {
        MercadoPago\SDK::setAccessToken(env('MERCADOPAGO_ACCESS_TOKEN'));

        // Crie um pagamento baseado no método e no total
        if ($dadosPedido['formaPagamento'] === 'Pix') {
            return $this->processarPagamentoPix($dadosPedido);
        } elseif ($dadosPedido['formaPagamento'] === 'Link') {
            return $this->processarPagamentoLink($dadosPedido);
        }

        throw new \Exception('Forma de pagamento não suportada.');
    }

    private function processarPagamentoPix(array $dadosPedido)
    {
        $payment = new MercadoPago\Payment();
        $payment->transaction_amount = $dadosPedido['total'];
        $payment->description = "Pedido ID: {$dadosPedido['numeroPedido']}";
        $payment->payment_method_id = 'pix';
        $payment->payer = [
            "email" => "client@example.com",
            "first_name" => $dadosPedido['cliente']['nome'],
            "last_name" => "Morinaka", // Nome fictício
            "phone" => [
              "area_code" => "71",
              "number" => "988926748"
            ]
        ];
        $payment->save();

        return $payment->init_point; // Retorna o link de pagamento
    }

    private function processarPagamentoLink(array $dadosPedido)
    {
        $payment = new MercadoPago\Payment();
        $payment->transaction_amount = $dadosPedido['total'];
        $payment->description = "Pedido ID: {$dadosPedido['numeroPedido']}";
        $payment->payment_method_id = 'credit_card'; // ou outro método
        $payment->payer = [
            "email" => "client@example.com",
            "first_name" => $dadosPedido['cliente']['nome'],
            "last_name" => "Morinaka",
            "phone" => [
              "area_code" => "71",
              "number" => "988926748"
            ]
        ];
        $payment->save();

        return $payment->init_point; // Retorna o link de pagamento
    }

}
