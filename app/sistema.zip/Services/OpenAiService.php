<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class OpenAiService
{
    protected $apiKey;
    protected $apiUrl;
    protected $defaultModel;

    public function __construct()
    {
        $this->apiKey = env('OPENAI_API_KEY');
        $this->urlOpenAi = env('OPENAI_API_URL');
        $this->defaultModel = env('OPENAI_DEFAULT_MODEL');
    }

    /**
     * Faz uma requisição à API do OpenAI para gerar uma resposta com GPT-4.
     *
     * @param string $prompt Texto de entrada para o modelo.
     * @param array $context Contexto adicional da conversa (mensagens anteriores).
     * @param int $maxTokens Número máximo de tokens na resposta.
     * @param string|null $model Modelo a ser utilizado (padrão: configurado no .env).
     * @return string Resposta gerada pela IA.
     */

     public function gerarResposta($prompt, $context = [], $maxTokens = 500, $model = null)
     {
         \Log::info('Iniciando a geração de resposta da IA', [
             'prompt' => $prompt,
             'context' => $context,
             'maxTokens' => $maxTokens,
             'model' => $model,
             'api_url' => $this->apiUrl // Verifique a URL da API aqui.
         ]);

         $model = $model ?? $this->defaultModel;

         $context = $context ?? [];
         if (!is_array($context)) {
             $context = (array) $context;
         }

         // Filtra itens inválidos do contexto
         $context = array_filter($context, function ($item) {
             return is_array($item) && isset($item['role']) && isset($item['content']);
         });

         // Verifica se o prompt é válido
         if (!is_string($prompt)) {
             \Log::error('O prompt fornecido não é uma string válida.', ['prompt' => $prompt]);
             throw new \Exception('O prompt fornecido não é uma string válida.');
         }

         // Mescla mensagens
         $messages = array_merge(
             $context,
             [['role' => 'user', 'content' => $prompt]]
         );

         // Valida estrutura final
         foreach ($messages as $key => $message) {
             if (!is_array($message) || !isset($message['role']) || !isset($message['content'])) {
                 \Log::error("Formato inválido detectado na mensagem.", ['index' => $key, 'message' => $message]);
                 throw new \Exception('Formato inválido no array de mensagens.');
             }
         }

         try {
             \Log::info('Enviando requisição para a API do OpenAI', [
                 'messages' => $messages
             ]);

             $response = Http::withHeaders([
                 'Authorization' => 'Bearer ' . $this->apiKey,
                 'Content-Type' => 'application/json',
             ])->post($this->urlOpenAi, [
                 'model' => $model,
                 'messages' => $messages,
                 'max_tokens' => $maxTokens // Adicionei max_tokens
             ]);

             if ($response->successful()) {
                 $conteudo = $response->json()['choices'][0]['message']['content'] ?? 'Sem resposta gerada pela IA.';
                 \Log::info('Resposta recebida com sucesso', ['conteudo' => $conteudo]);
                 return $this->formatarResposta($conteudo);
             } else {
                 \Log::error('Erro na API do OpenAI: ' . $response->body(), [
                     'prompt' => $prompt,
                     'status' => $response->status()
                 ]);
                 throw new \Exception('Erro ao acessar a API do OpenAI.');
             }
         } catch (\Exception $e) {
             \Log::error('Erro ao gerar resposta da IA: ' . $e->getMessage(), [
                 'prompt' => $prompt,
                 'context' => $context
             ]);

             throw $e;
         }
     }

    /**
     * Formata a resposta gerada pela IA, dividindo em partes menores.
     *
     * @param string $resposta Resposta completa gerada pela IA.
     * @param int $tamanhoMaximo Tamanho máximo de cada mensagem antes da quebra.
     * @return string Resposta formatada com quebras "&#".
     */
    public function formatarResposta($resposta, $tamanhoMaximo = 500)
    {
        // Remove espaços em branco extras
        $resposta = trim($resposta);

        // Divide a resposta em partes menores com base no tamanho máximo
        if (strlen($resposta) <= $tamanhoMaximo) {
            return $resposta;
        }

        $partes = wordwrap($resposta, $tamanhoMaximo, "\n", true);
        $partes = explode("\n", $partes);

        // Adiciona o separador de mensagens entre as partes
        return implode(' &# ', $partes);
    }
}
